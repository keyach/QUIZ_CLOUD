const express = require('express');
const router = express.Router();
const Question = require('../models/Question');

// API to get questions
router.get('/', async (req, res) => {
    const { type, number } = req.query;
    try {
        const questions = await Question.find({ type }).limit(parseInt(number));
        res.json(questions);
    } catch (err) {
        res.status(500).json({ error: 'Error fetching questions' });
    }
});

module.exports = router;

document.addEventListener('DOMContentLoaded', () => {
    let player = JSON.parse(localStorage.getItem('player'));
    let currentQuestion = 0;
    let questions = [];
    let score = 0;
    let timer;

    // Set player name
    document.getElementById('playerName').innerText = `Player: ${player.name}`;
    const feedback = document.getElementById('feedback') || document.createElement('div');
    feedback.id = 'feedback';
    document.querySelector('.game-container').appendChild(feedback);

    // Fetch questions
    fetch(`http://localhost:5000/api/game?type=${player.type}&number=${player.number}`)
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) {
                feedback.innerText = 'No questions found for this type!';
                return;
            }
            questions = data.slice(0, player.number);
            document.getElementById('score').innerText = `Score: ${score}`;
            showQuestion();
        })
        .catch(err => {
            console.error('Error fetching questions:', err);
            feedback.innerText = 'Error loading questions!';
        });

    function showQuestion() {
        if (currentQuestion >= questions.length) {
            endGame();
            return;
        }
        document.getElementById('questionBox').innerText = questions[currentQuestion].question;
        document.getElementById('answerInput').value = '';
        feedback.innerText = '';
        startTimer();
    }

    function startTimer() {
        let timeLeft = 40;
        document.getElementById('timer').innerText = `⏳ ${timeLeft}`;
        clearInterval(timer);
        timer = setInterval(() => {
            timeLeft--;
            document.getElementById('timer').innerText = `⏳ ${timeLeft}`;
            if (timeLeft <= 0) {
                clearInterval(timer);
                currentQuestion++;
                showQuestion();
            }
        }, 1000);
    }

    function endGame() {
        clearInterval(timer);
        document.getElementById('questionBox').innerText = 'Game Over!';
        document.getElementById('answerInput').style.display = 'none';
        document.getElementById('submitBtn').style.display = 'none';
        document.getElementById('timer').style.display = 'none';
        document.getElementById('score').innerText = `Final Score: ${score}`;
        feedback.innerText = `You answered ${score / 10} out of ${questions.length} questions correctly!`;

        // Add Play Again button
        const playAgainBtn = document.createElement('button');
        playAgainBtn.id = 'playAgainBtn';
        playAgainBtn.innerText = 'Play Again';
        playAgainBtn.style.marginTop = '20px'; // Basic styling
        document.querySelector('.game-container').appendChild(playAgainBtn);

        playAgainBtn.addEventListener('click', () => {
            window.location.href = 'index.html'; // Replace with your landing page URL
        });
    }

    document.getElementById('submitBtn').addEventListener('click', () => {
        const answerInputRaw = document.getElementById('answerInput').value;
        const answerInput = answerInputRaw.trim().toLowerCase().replace(/\s+/g, '');
        const correctAnswerRaw = questions[currentQuestion].correctAnswer || '';
        const correctAnswer = String(correctAnswerRaw).trim().toLowerCase().replace(/\s+/g, '');

        if (answerInput === correctAnswer) {
            score += 10;
            document.getElementById('score').innerText = `Score: ${score}`;
            feedback.innerText = 'Correct Answer!';
            feedback.style.color = 'green';
            clearInterval(timer);
            currentQuestion++;
            showQuestion();
        } else {
            feedback.innerText = 'Incorrect Answer! Try again.';
            feedback.style.color = 'red';
        }
    });
});
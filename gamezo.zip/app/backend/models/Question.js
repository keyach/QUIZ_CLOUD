const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
    question: String,
    correctAnswer: String,
    type: String // dsa, os, oops, etc.
});

module.exports = mongoose.model('Question', questionSchema);
